//
//  RmmRelay.cpp
//  clocksync
//
//  Created by Zeyu Jin on 1/10/15.
//  Copyright (c) 2015 Zeyu Jin. All rights reserved.
//

#include "RmmRelay.h"

RmmRelay::RmmRelay(const char * port) {
    this->port = port;
    
    
}

