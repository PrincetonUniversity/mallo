//
//  RmmNode.cpp
//  clocksync
//
//  Created by Zeyu Jin on 1/6/15.
//  Copyright (c) 2015 Zeyu Jin. All rights reserved.
//

#include "RmmNode.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

#include <math.h>


void error(int num, const char *m, const char *path);

int echo_handler(const char *path, const char *types, lo_arg ** argv,
                 int argc, void *data, void *user_data);

int quit_handler(const char *path, const char *types, lo_arg ** argv,
                 int argc, void *data, void *user_data);


////////////////////
///////// DEF of RmmNode
////////////////////


RmmNode::RmmNode(const char * port, const char * nodeId) {
    this->localPort = port;
    this->nodeId = nodeId;
    this->connectedTo.status = RMM_OFFLINE;
}

void RmmNode::restart(const char * port, bool useTcp) {
    // turn off UDP connection
    
    std::string portStr = port;
    if (inited && portStr == this->localPort) {
        // no need to restart
        return;
    }
    else {
        localPort = portStr;
    }
    
    lo_timetag_now(&t0);
    
    inited = false;
    st = lo_server_thread_new_with_proto(localPort.c_str(), useTcp ? LO_TCP : LO_UDP, error);
    if (!st) {
        printf("Could not create server thread.\n");
        exit(1);
    }
    server = lo_server_thread_get_server(st);
    
    /* add method that will match the path /quit with no args */
    lo_server_thread_add_method(st, "/quit", "", quit_handler, NULL);
    
    /* add method that will match any path and args */
    lo_server_thread_add_method(st, NULL, NULL, echo_handler, this);
    
    lo_server_thread_start(st);
    
    printf("[%s-SERVER] node created %s, TCP = %d\n", nodeId.c_str(), lo_server_get_url(server), useTcp);
    
    inited = true;
}

void RmmNode::handleJoin(lo_address target) {
    RmmConn connection;
    const char *host = lo_address_get_hostname(target);
    const char *port = lo_address_get_port(target);
    connection.remoteIp = host;
    connection.remotePort = port;
    // connection.remoteConn = lo_address_new_with_proto(useTcp?LO_TCP:LO_UDP, connection.remoteIp.c_str(), connection.remotePort.c_str());
    printf("[%s-SERVER] %s:%s requested to join\n", this->nodeId.c_str(), host, port);
    lo_send_from(target, server, LO_TT_IMMEDIATE, "/joined", "s", "Welcome");
}

void RmmNode::start(bool useTcp) {
    if (inited) {
        if (useTcp != this->useTcp) {
            close();
            clientReset();
        }
        else {
            return; // no need to restart the server
        }
    }
    this->useTcp = useTcp;
    restart(this->localPort.c_str(), useTcp);
}

void RmmNode::close() {
    lo_server_thread_stop(this->st);
    lo_server_thread_free(this->st);
    lo_server_free(this->server);
}

void RmmNode::addRelayConnection(const char *ip, const char *port) {
    RmmConn conn;
    relayConnections.push_back(conn);
    int index = (int)relayConnections.size() - 1;
    relayConnections[index].remoteIp = ip;
    relayConnections[index].remotePort = port;
    relayConnections[index].remote = lo_address_new_with_proto(useTcp?LO_TCP:LO_UDP, ip, port);
    if (!relayConnections[index].remote) {
        printf("[%s:CLIENT] Error creating destination address.\n", this->nodeId.c_str());
    }
    printf("[%s-CLIENT] RELAY %s:%s\n", this->nodeId.c_str(), relayConnections[index].remoteIp.c_str(), relayConnections[index].remotePort.c_str());
}

double RmmNode::time() {
    lo_timetag t1;
    lo_timetag_now(&t1);
    return lo_timetag_diff(t1, t0) + forcedoffset;
}

double RmmNode::remote_time() {
    lo_timetag t1;
    lo_timetag_now(&t1);
    return lo_timetag_diff(t1, t0) + forcedoffset + timeOffset;
}

bool RmmNode::isDebug() {
    return _debug;
}

void RmmNode::multisend(lo_address target, lo_message &msg, const char * path) {
    lo_send_message_from(client, server, path, msg);
}

//// SEND**** FUNCTIONS

void RmmNode::sendChat(const char * content) {
    if (clientInited) {
        lo_send_from(client, server, LO_TT_IMMEDIATE, "/chat", "s", content);
    }
}

void RmmNode::sendSched(double t_ms, int midiCode, int content) {
    if (clientInited) {
        lo_send_from(client, server, LO_TT_IMMEDIATE, "/sched", "ddii", time(), t_ms, midiCode, content);
        for (int a = 0; a < relayConnections.size(); ++a) {
            // lo_address relay = lo_address_new_with_proto(useTcp?LO_TCP:LO_UDP, relayConnections[a].remoteIp.c_str(), relayConnections[a].remotePort.c_str());
            std::string path = "/sched";
            int err = lo_send_from(relayConnections[a].remote, server, LO_TT_IMMEDIATE, "/fwd", "sssddii", path.c_str(), connectedTo.remoteIp.c_str(), connectedTo.remotePort.c_str(), time(), t_ms, midiCode, content);
            if (err < 0) {
                printf("[%s-CLIENT] cannot access relay %d\n", this->nodeId.c_str(), err);
            }
            
            // lo_address_free(relay);
        }
    }
}

void RmmNode::sendClockRequest() {
    _recsynctime = time();
    if (clientInited) {
        lo_send_from(client, server, LO_TT_IMMEDIATE, "/syncreq", "d", _recsynctime);
    }
}

void RmmNode::sendLatencyTest() {
    _lattesttime = remote_time();
    if (clientInited) {
        lo_send_from(client, server, LO_TT_IMMEDIATE, "/lattreq", "d", _recsynctime);
    }
}

void RmmNode::handleClockRequest(lo_address target) {
    lo_send_from(target, server, LO_TT_IMMEDIATE, "/clock", "d", time());
}

void RmmNode::handleClockRequest(lo_address target, double simlat) {
    lo_send_from(target, server, LO_TT_IMMEDIATE, "/clock", "d", time()+ simlat / 2.0f);
}

void RmmNode::handleClockReply(lo_address target, double t_remote) {
    // send nothing
    // calculate time difference
    double t2 = time();
    if (_recsynctime > 0) {
        timeOffset = t_remote - (t2 + _recsynctime) / 2;
        _recsynctime = 0;
        printf("[%s-SERVER] TIME(%.3f,%.3f%.3f))\n", this->nodeId.c_str(), _recsynctime, t_remote, t2);
        printf("[%s-SERVER] TIME-offset adjusted to %.3f\n", this->nodeId.c_str(), timeOffset);
    }
    else {
        printf("[%s:ERROR] clock-reply recieved without being triggered\n", this->nodeId.c_str());
    }
    
}

void RmmNode::handleLatencyRequest(lo_address target) {
    lo_send_from(target, server, LO_TT_IMMEDIATE, "/latt", "d", time());
}

void RmmNode::handleLatencyTest(lo_address target, double t) {
    if (_lattesttime > 0) {
        double rtt = remote_time() - _lattesttime;
        printf("[%s-CLIENT] latency = %.3f\n", this->nodeId.c_str(), t - _lattesttime);
        double owt = t - _lattesttime;
        lat_oneway.push_back(owt);
        lat_rtt.push_back(rtt);
        
        _lattesttime = 0;
        double std = 0;
        double m = 0;
        int count = 0;
        for (int a = (int)lat_oneway.size() - 1; a >= 0 && a >= (int)lat_oneway.size() - 32; a--, count++) {
            m += lat_oneway[a];
        }
        m = m / (double)count;
        for (int a = (int)lat_oneway.size() - 1; a >= 0 && a >= (int)lat_oneway.size() - 32; a--) {
            std += (lat_oneway[a] - m) * (lat_oneway[a] - m);
        }
        std = std / (double)count;
        std = sqrt(std);
        onLatency(owt, rtt, std + std + m);

    }
    else {
        printf("[%s-ERROR] latency test result got before asked\n", this->nodeId.c_str());
    }
}

void error(int num, const char *msg, const char *path)
{
    printf("liblo server error %d in path %s: %s\n", num, path, msg);
    fflush(stdout);
}


void RmmNode::join(const char *remoteIp, const char *remotePort) {
    this->connectedTo.remoteIp = remoteIp;
    this->connectedTo.remotePort = remotePort;
    clientInited = false;
    clientReset();
    int r = lo_send_from(client, server, LO_TT_IMMEDIATE, "/join", "i", 1);
    if (r < 0)
        printf("[%s:CLIENT-JOIN] Error sending initial message.\n", this->nodeId.c_str());
    clientInited = true;
    connectedTo.status = RMM_TOJOIN;
    _timeouttime = time();
}

void RmmNode::clientReset() {
    if (clientInited == true) {
        lo_address_free(client);
    }
    client = lo_address_new_with_proto(useTcp?LO_TCP:LO_UDP, this->connectedTo.remoteIp.c_str(), this->connectedTo.remotePort.c_str());
    if (!client) {
        printf("[%s:CLIENT] Error creating destination address.\n", this->nodeId.c_str());
    }
}

void RmmNode::poll() {
    double t0 = time();
    double t1 = remote_time();
    
    // printf("t=%f (next-cmd %.3f, next-ev %.3f)\n", t0, t_schedcmd, event.time);
    if (t_schedcmd > 0 && t0 > t_schedcmd) {
        exec_rmmcode(code_schedcmd);
        if (t0 > t_schedcmd) {
            t_schedcmd = 0;
        }
    }
    if (event.time > 0 && t1 > event.time) {
        exec_event(event);
        if (t1 > event.time) {
            event.time = 0;
        }
    }
    if (t0 > latt) {
        latt = ((int)t0) + 1;
        if (connectedTo.status == RMM_ALIVE)
            sendLatencyTest();
    }
}

void RmmNode::setDebug(bool debug) {
    _debug = debug;
}

void RmmNode::exec_rmmcode(RmmCodes code) {
    switch (code) {
        case RMM_CLOCKSYNC:
            sendClockRequest();
            if (clocksynccount > 0) {
                clocksynccount --;
                delayedcommand(time() + 0.5, RMM_CLOCKSYNC);
            }
            else {
                clocksynccount = 3;
                delayedcommand(time() + 20, RMM_CLOCKSYNC);
                connectedTo.status = RMM_ALIVE;
            }
            break;
            
        case RMM_KEEPALIVE:
            sendKeepAlive();
            break;
            
        case RMM_CLOCKREP:
            double tdf = (rand()%100)/1000.0 + 0.02;
            handleClockRequest(tempaddr, tdf);
            break;
            
    }
}

void RmmNode::sendKeepAlive() {
    _recsynctime = time();
    if (clientInited) {
        lo_send_from(client, server, LO_TT_IMMEDIATE, "/syncreq", "d", _recsynctime);
    }
}

void RmmNode::exec_event(RmmEvent &ev) {
    this->onEvent(ev.cmd, ev.arg);
}

lo_server RmmNode::getserverptr() {
    return server;
}

void RmmNode::setForcedTimeOffset(double toff) {
    this->forcedoffset = toff;
}

void RmmNode::schedule(double srctime, double t, int cmd, int arg) {
    if (srctime > _schedtracetime) {
        event.time = t;
        event.cmd = cmd;
        event.arg = arg;
        printf("[%s-SERVER] EVENT SCHEDULED (%.3f, %d, %d)\n", this->nodeId.c_str(), t, cmd, arg);
    }
}

void RmmNode::handleChat(lo_address target, char * content) {
    const char *host = lo_address_get_hostname(target);
    const char *port = lo_address_get_port(target);
    printf("[%s:%s SAYS] %s\n", host, port, content);
    onChat(content);
}

void RmmNode::handleJoinSuccess(lo_address target) {
    if (connectedTo.status == RMM_TOJOIN) {
        connectedTo.status = RMM_CONNECTED;
        // start clock sync one second later
        delayedcommand(time() + 1, RMM_CLOCKSYNC);
        printf("[%s:CLIENT] join sucessful\n", this->nodeId.c_str());
    }
    else {
        printf("[%s:ERROR] join-successs received without asked\n", this->nodeId.c_str());
    }
}

void RmmNode::delayedcommand(double t_ms, RmmCodes code) {
    t_schedcmd = t_ms;
    code_schedcmd = code;
}

bool RmmNode::isUsingTcp() {
    return useTcp;
}


////////////////////
///////// For C-style callback functions
////////////////////

/* catch any incoming messages, display them, and send them
 * back. */
int echo_handler(const char *path, const char *types, lo_arg ** argv,
                 int argc, void *data, void *user_data)
{
    int i;
    RmmNode * node = (RmmNode *)(user_data);
    lo_message m = (lo_message)data;
    lo_address a = lo_message_get_source(m);
    node->tempaddr = a;
    // lo_server  s = node->getserverptr();
    // const char *host = lo_address_get_hostname(a);
    // const char *port = lo_address_get_port(a);
    
    std::string pathstr = path;
    
    if (!a) {
        printf("[FATAL] Cannot parse message address\n");
        return 0;
    }
    if (pathstr == "/sched") {
        double t = *(double*)argv[0];
        double t_pred = *(double*)argv[1];
        int cmd = *(int*)argv[2];
        int arg = *(int*)argv[3];
        node->schedule(t, t_pred, cmd, arg);
    }
    else if (pathstr == "/syncreq") {
        node->handleClockRequest(a);
    }
    else if (pathstr == "/chat") {
        node->handleChat(a, (char*)argv[0]);
    }
    else if (pathstr == "/clock") {
        node->handleClockReply(a, *(double*)argv[0]);
    }
    else if (pathstr == "/latt") {
        node->handleLatencyTest(a, *(double*)argv[0]);
    }
    else if (pathstr == "/join") {
        node->handleJoin(a);
    }
    else if (pathstr == "/joined") {
        node->handleJoinSuccess(a);
    }
    else if (pathstr == "/lattreq") {
        node->handleLatencyRequest(a);
    }
    else if (pathstr == "/fwd") {
        std::string path = (char*)argv[0];
        std::string dstIp = (char*)argv[1];
        std::string dstPort = (char*)argv[2];
        const char * types = lo_message_get_types(m);

        lo_message msg = lo_message_new();
        size_t len = strlen(types);
        for (int a = 3; a < len; ++a) {
            if (types[a] == 'd') {
                lo_message_add_double(msg, *((double*)argv[a]));
            }
            else if (types[a] == 'f') {
                lo_message_add_float(msg, *((float*)argv[a]));
            }
            else if (types[a] == 's') {
                lo_message_add_string(msg, (char*)argv[a]);
            }
            else if (types[a] == 'i') {
                lo_message_add_int32(msg, *((int*)argv[a]));
            }
        }
        
        lo_address fwdaddr = lo_address_new_with_proto(node->isUsingTcp()?LO_TCP:LO_UDP, dstIp.c_str(), dstPort.c_str());
        lo_send_message_from(fwdaddr, node->getserverptr(), path.c_str(), msg);
        printf("[F>>>%s:%s] (", dstIp.c_str(), dstPort.c_str());
        for (i = 0; i < argc; i++) {
            lo_arg_pp((lo_type)types[i], argv[i]);
            printf(", ");
        }
        lo_address_free(fwdaddr);
        printf(")\n");
    }
    else {
        printf("[UNKNOWN:%s] message(", path);
        for (i = 0; i < argc; i++) {
            // printf(" arg %d '%c' ", i, types[i]);
            lo_arg_pp((lo_type)types[i], argv[i]);
            printf(", ");
        }
        printf("\b\b)");
        printf("\n");
    }
    return 0;
}


int quit_handler(const char *path, const char *types, lo_arg ** argv,
                 int argc, void *data, void *user_data)
{
    printf("quitting\n\n");
    fflush(stdout);
    
    return 0;
}