//
//  RmmRelay.h
//  clocksync
//
//  Created by Zeyu Jin on 1/10/15.
//  Copyright (c) 2015 Zeyu Jin. All rights reserved.
//

#ifndef __clocksync__RmmRelay__
#define __clocksync__RmmRelay__

#include <stdio.h>
#include <string>
#include <lo/lo.h>

class RmmRelay {
    std::string port;
public:
    RmmRelay(const char * port);
    
};

#endif /* defined(__clocksync__RmmRelay__) */
