//
//  RmmNode.h
//  clocksync
//
//  Created by Zeyu Jin on 1/6/15.
//  Copyright (c) 2015 Zeyu Jin. All rights reserved.
//

#ifndef __clocksync__RmmNode__
#define __clocksync__RmmNode__

#include <stdio.h>
#include <string>
#include <vector>

#include <lo/lo.h>

enum RmmCodes {
    RMM_CLOCKSYNC = 0x1,
    RMM_KEEPALIVE = 0x2,
    RMM_CLOCKREP = 0x10
};

enum RmmStats {
    RMM_OFFLINE, RMM_TOJOIN, RMM_SUSPENDED, RMM_ALIVE, RMM_CONNECTED
};

struct RmmConn {
    std::string remoteIp;
    std::string remotePort;
    RmmStats status;
    lo_address  remote;
};

struct RmmEvent {
    int cmd;
    int arg;
    double time;
};

class RmmListener {
public:
    virtual void onEvent(int cmd, int arg) = 0;
    virtual void onChat(const char * content) = 0;
    virtual void onLatency(double ol, double rtl, double upper) = 0;
};

class RmmNode : public RmmListener {
    bool inited = false;
    bool useTcp = false;
    bool clientInited = false;
    RmmConn connectedTo;
    
    std::string localPort;
    
protected:
    
    std::vector<double> lat_oneway;
    std::vector<double> lat_rtt;
    std::vector<RmmConn> connections;
    std::vector<RmmEvent> events;
    
    std::vector<RmmConn> relayConnections;
    
    lo_server server;
    lo_server_thread st;
    
    lo_address client;
    
    
    lo_timetag t0;
    double timeOffset = 0;
    double forcedoffset = 0;
    
protected:
    
    std::string nodeId;
    bool _debug = false;
    
protected:
    int clocksynccount = 5;
    double _recsynctime = 0;
    double _lattesttime = 0;
    double _timeouttime = 0;
    double _schedtracetime = 0;
    double latt = 0;
    double _latestimate = 0;
    
public:
    RmmNode(const char * port, const char * nodeId);
    void start(bool useTcp);
    void join(const char * remoteIp, const char * remotePort);
    void restart(const char * port, bool useTcp);
    void poll();
    void schedule(double srctime, double t, int cmd, int arg);
    double time();
    double remote_time();
    void exec_rmmcode(RmmCodes code);
    void exec_event(RmmEvent &ev);
    
    void addRelayConnection(const char * ip, const char * port);
    
    // for debug
    void setForcedTimeOffset(double toff);
    void setDebug(bool debug);
    bool isDebug();
    lo_address tempaddr;
    
    void multisend(lo_address target, lo_message &msg, const char * path);
    bool isUsingTcp();
    
protected:
    void close();
    void clientReset();
    
public: // sending messages
    
    void sendSched(double t_ms, int midiCode, int content);
    void sendClockRequest();
    void sendKeepAlive();
    void sendLatencyTest();
    
protected:
    double t_schedcmd; RmmCodes code_schedcmd;
    RmmEvent event;
    
public:
    // SERVER actions
    void delayedcommand(double t_ms, RmmCodes code);
    void handleClockRequest(lo_address target);
    void handleClockRequest(lo_address target, double latt);
    void handleJoin(lo_address target);
    void handleLatencyRequest(lo_address target);
    void handleForward(lo_address target);
    
    // CLIENT ACTIONS
    void handleClockReply(lo_address target, double time);
    void handleChat(lo_address target, char * content);
    void handleJoinSuccess(lo_address target);
    virtual void handleLatencyTest(lo_address target, double t);
    
    // FOR RELAY
    void rtt2relay();
    
public:  // user messages
    void sendChat(const char * content);
    
public:
    lo_server getserverptr();
};

#endif /* defined(__clocksync__RmmNode__) */
