//
//  main.cpp
//  clocksync
//
//  Created by Zeyu Jin on 11/25/14.
//  Copyright (c) 2014 Zeyu Jin. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctime>

#include "RmmApp.h"

int main() {
    RmmApp relay("4664", "R0");
    relay.start(true);
    
    RmmApp node("7676", "N0", "9192");
    RmmApp node2("1919", "N1", "9192");
    
    node.start(true);
    node.setDebug(true);
    node.setForcedTimeOffset(10); // is 10 seconds ahead of the client
    node.addmapping(1, "/hit");
    
    node2.start(true);
    node2.join("localhost", "7676");
    node2.addRelayConnection("localhost", "4664");
    
    char temp[128];
    lo_timetag t0, t1;
    lo_timetag_now(&t0);
    
    int counter = 0;
    
    while (true) {
        lo_timetag_now(&t1);
        // sprintf(temp, "t=%.2fs", lo_timetag_diff(t0, t1));
        node.poll();
        node2.poll();
        relay.poll();
        usleep(1000);
        // node2.sendChat(temp);
        if (counter++ % 525 == 0) {
            node2.sendSched(node2.remote_time() + 0.1, 1, 3);
        }
        
    }
    
    return 0;
}

